import React, { useEffect, useState, useRef } from 'react';
import {
  SafeAreaView,
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Image,
  Dimensions,
  Animated,
  Vibration,
  ImageBackground,
} from 'react-native';

// SEU FUNDO FLORAL AQUI (verifique o nome correto do arquivo e a extensão .png/.jpg)
const imagemFundo = require('./assets/fundo.jpg'); 

const { width } = Dimensions.get('window');
const COLUNAS = 4;
const ESPACAMENTO = 10;
const TAMANHO_CARTA = (width - ESPACAMENTO * (COLUNAS + 1)) / COLUNAS;

// Suas fotos de cartas
const imagens = [
  { uri: 'https://images.pexels.com/photos/35341653/pexels-photo-35341653.jpeg?auto=compress&cs=tinysrgb&w=300' },
  { uri: 'https://images.pexels.com/photos/21802676/pexels-photo-21802676.jpeg?auto=compress&cs=tinysrgb&w=300' },
  { uri: 'https://images.pexels.com/photos/35423128/pexels-photo-35423128.jpeg?auto=compress&cs=tinysrgb&w=300' },
  { uri: 'https://images.pexels.com/photos/9518531/pexels-photo-9518531.jpeg?auto=compress&cs=tinysrgb&w=300' },
  { uri: 'https://images.pexels.com/photos/11238598/pexels-photo-11238598.jpeg?auto=compress&cs=tinysrgb&w=300' },
  { uri: 'https://images.pexels.com/photos/5743786/pexels-photo-5743786.jpeg?auto=compress&cs=tinysrgb&w=300' },
  { uri: 'https://images.pexels.com/photos/28430522/pexels-photo-28430522.jpeg?auto=compress&cs=tinysrgb&w=300' },
  { uri: 'https://images.pexels.com/photos/37343274/pexels-photo-37343274.jpeg?auto=compress&cs=tinysrgb&w=300' },
];

function embaralhar(lista) {
  const novaLista = [...lista];
  for (let i = novaLista.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [novaLista[i], novaLista[j]] = [novaLista[j], novaLista[i]];
  }
  return novaLista;
}

function criarCartas() {
  let cartas = [];
  imagens.forEach((imagem, index) => {
    cartas.push({ id: index, uid: `${index}-a`, imagem, virada: false, encontrada: false });
    cartas.push({ id: index, uid: `${index}-b`, imagem, virada: false, encontrada: false });
  });
  return embaralhar(cartas);
}

const CartaItem = ({ carta, onPress, bloqueado }) => {
  const animacao = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(animacao, {
      toValue: carta.virada ? 1 : 0,
      duration: 300,
      useNativeDriver: true,
    }).start();
  }, [carta.virada]);

  const frenteInterpolada = animacao.interpolate({
    inputRange: [0, 1],
    outputRange: ['0deg', '180deg'],
  });

  const versoInterpolado = animacao.interpolate({
    inputRange: [0, 1],
    outputRange: ['180deg', '360deg'],
  });

  return (
    <TouchableOpacity
      style={styles.cartaContainer}
      activeOpacity={0.9}
      disabled={bloqueado || carta.virada || carta.encontrada}
      onPress={() => onPress(carta)}>
      
      {/* Verso da carta */}
      <Animated.View style={[styles.carta, styles.verso, { transform: [{ rotateY: frenteInterpolada }] }]}>
        <Text style={styles.interrogacao}>?</Text>
      </Animated.View>

      {/* Frente da carta */}
      <Animated.View style={[styles.carta, styles.frente, { transform: [{ rotateY: versoInterpolado }] }]}>
        <Image source={carta.imagem} style={styles.imagem} resizeMode="cover" />
      </Animated.View>
    </TouchableOpacity>
  );
};

export default function App() {
  const [cartas, setCartas] = useState([]);
  const [primeiraCarta, setPrimeiraCarta] = useState(null);
  const [bloqueado, setBloqueado] = useState(false);
  const [jogadas, setJogadas] = useState(0);
  const [paresEncontrados, setParesEncontrados] = useState(0);
  const [jogadorAtual, setJogadorAtual] = useState(1);
  const [pontosJogador1, setPontosJogador1] = useState(0);
  const [pontosJogador2, setPontosJogador2] = useState(0);


  useEffect(() => {
    iniciarJogo();
  }, []);

  function iniciarJogo() {
    setCartas(criarCartas());
    setPrimeiraCarta(null);
    setJogadas(0);
    setParesEncontrados(0);
    setBloqueado(false);
    setJogadorAtual(1);
    setPontosJogador1(0);
    setPontosJogador2(0);
  }

  function selecionarCarta(cartaSelecionada) {
    if (bloqueado || cartaSelecionada.virada || cartaSelecionada.encontrada) return;

    const novasCartas = cartas.map((item) =>
      item.uid === cartaSelecionada.uid ? { ...item, virada: true } : item
    );
    setCartas(novasCartas);

    if (!primeiraCarta) {
      setPrimeiraCarta(cartaSelecionada);
    } else {
      setJogadas((prev) => prev + 1);
      verificarPar(primeiraCarta, cartaSelecionada);
    }
  }

  function verificarPar(carta1, carta2) {
  setBloqueado(true);

  if (carta1.id === carta2.id) {
    Vibration.vibrate(50);

    setTimeout(() => {
      setCartas((prev) =>
        prev.map((item) =>
          item.id === carta1.id
            ? { ...item, encontrada: true }
            : item
        )
      );

      setParesEncontrados((prev) => prev + 1);

      if (jogadorAtual === 1) {
        setPontosJogador1((prev) => prev + 1);
      } else {
        setPontosJogador2((prev) => prev + 1);
      }

      // Continua sendo a vez do mesmo jogador
      setPrimeiraCarta(null);
      setBloqueado(false);

    }, 400);

  } else {

    setTimeout(() => {

      setCartas((prev) =>
        prev.map((item) =>
          item.uid === carta1.uid || item.uid === carta2.uid
            ? { ...item, virada: false }
            : item
        )
      );

      setPrimeiraCarta(null);

      // troca de jogador
      setJogadorAtual((prev) => (prev === 1 ? 2 : 1));

      setBloqueado(false);

    }, 900);
  }
}

  const jogoFinalizado = paresEncontrados === imagens.length;

  return (
    <ImageBackground source={imagemFundo} resizeMode="cover" style={styles.background}>
      <SafeAreaView style={styles.container}>
        {jogoFinalizado ? (
          <View style={styles.centralizar}>
            <Text style={styles.titulo}>Parabéns!</Text>
            <Text style={styles.vitoria}>
              {pontosJogador1 > pontosJogador2
              ? 'O(A) Jogador(a) 1 venceu!'
              : pontosJogador2 > pontosJogador1
              ? 'O(A) Jogador(a) 2 venceu!'
              : 'Empate!'}
            </Text>
            <Text style={styles.movimentos}>
              Placar Final: {pontosJogador1} x {pontosJogador2}
            </Text>
            <Text style={styles.movimentos}>Total de Jogadas: {jogadas}</Text>
            <TouchableOpacity style={styles.botao} onPress={iniciarJogo}>
              <Text style={styles.textoBotao}>Jogar Novamente</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <>
            <Text style={styles.titulo}>Jogo da Memória</Text>
            <Text style={styles.movimentos}>Jogadas | {jogadas} |</Text>
            <Text style={styles.vez}>Vez do(a) Jogador(a) {jogadorAtual}</Text>
            <Text style={styles.placar}>Jogador(a) 1 | {pontosJogador1} |  x  | {pontosJogador2} | Jogador(a) 2</Text>
            <View style={styles.tabuleiro}>
              {cartas.map((carta) => (
                <CartaItem
                  key={carta.uid}
                  carta={carta}
                  bloqueado={bloqueado}
                  onPress={selecionarCarta}
                />
              ))}
               <Text style={styles.marcadagua}>desenvolvido por @isadorapedon, @helenadalponso e @isabellimartielo</Text>
            </View>

            <TouchableOpacity style={styles.botao} onPress={iniciarJogo}>
              <Text style={styles.textoBotao}>Reiniciar</Text>
            </TouchableOpacity>
          </>
        )}
      </SafeAreaView>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    width: '100%',
    height: '100%',
    opacity: '0.8',
  },
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'transparent', // Mantém o fundo totalmente visível
  },
  centralizar: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  titulo: {
    fontSize: 37,
    fontWeight: '800',
    color: '#6B3A4C', // Tom vinho/rosado escuro para legibilidade
    marginBottom: 0,
    marginTop: 50,
    fontFamily: 'century gothic',
  },
  movimentos: {
    fontSize: 15,
    fontWeight: '700',
    color: '#8A5265',
    marginBottom: 5,
    marginTop: 8,
    fontFamily: 'century gothic',
    backgroundColor: '#c9a5b1',
    paddingVertical: 8,
    paddingHorizontal: 9,
  },
  tabuleiro: {
    width: width,
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    paddingHorizontal: ESPACAMENTO / 2,
  },
  cartaContainer: {
    width: TAMANHO_CARTA,
    height: TAMANHO_CARTA,
    margin: ESPACAMENTO / 2,
  },
  carta: {
    width: '100%',
    height: '100%',
    borderRadius: 12,
    position: 'absolute',
    backfaceVisibility: 'hidden',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#5C2D3B',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 4,
  },
  verso: {
    backgroundColor: '#B76E79', // Rosa queimado / Rose Gold elegante para o verso da carta
  },
  frente: {
    backgroundColor: '#FFFFFF',
  },
  interrogacao: {
    color: '#FFFFFF',
    fontSize: 32,
    fontWeight: 'bold',
  },
  imagem: {
    width: '100%',
    height: '100%',
    borderRadius: 12,
  },
  botao: {
    marginTop: 24,
    backgroundColor: '#8A3B58', // Botão em tom vinho elegante
    paddingHorizontal: 32,
    paddingVertical: 14,
    borderRadius: 12,
    elevation: 4,
  },
  textoBotao: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
    fontFamily: 'century gothic',
  },
  vitoria: {
    fontSize: 20,
    marginBottom: 20,
    marginTop: 20,
    color: '#471f2e',
    fontWeight: '600',
    fontFamily: 'century gothic',
  },
  marcadagua: {
    fontSize: 9,
    color: 'black',
    marginBottom: -9,
    marginTop: 5,
    fontFamily: 'century gothic',
    textAlign: 'center',
  },
  vez: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#6B3A4C',
    marginBottom: 5,
  },

  placar: {
    fontSize: 16,
    color: '#c9a5b1',
    marginBottom: 15,
    fontWeight: '600',
    backgroundColor: '#6B3A4C',
    paddingVertical: 10,
    paddingHorizontal: 10,
  },
});
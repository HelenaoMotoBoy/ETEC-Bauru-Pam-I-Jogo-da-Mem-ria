import React, { useState } from 'react';
import {
  SafeAreaView,
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ImageBackground,
} from 'react-native';


import Jogo1Jogador from './JogoJogador1';
import Jogo2Jogadores from './JogoJogadores2';

const imagemFundo = require('./assets/fundo.jpg');

export default function App() {
  const [tela, setTela] = useState('menu');

  if (tela === 'umJogador') {
    return (
      <View style={{ flex: 1 }}>
        <Jogo1Jogador />

        <TouchableOpacity
          style={styles.botaoVoltar}
          onPress={() => setTela('menu')}>
          <Text style={styles.textoBotao1}>⬅ Voltar ao Menu</Text>
        </TouchableOpacity>
      </View>
    );
  }

  if (tela === 'doisJogadores') {
    return (
      <View style={{ flex: 1 }}>
        <Jogo2Jogadores />

        <TouchableOpacity
          style={styles.botaoVoltar}
          onPress={() => setTela('menu')}>
          <Text style={styles.textoBotao1}>⬅ Voltar ao Menu</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <ImageBackground
      source={imagemFundo}
      resizeMode="cover"
      style={styles.background}>
      <SafeAreaView style={styles.container}>
        <Text style={styles.titulo}>Flower's Memories</Text>

        <Text style={styles.subtitulo}>Escolha o modo de jogo:</Text>

        <TouchableOpacity
          style={styles.botao}
          onPress={() => setTela('umJogador')}>
          <Text style={styles.textoBotao}>🎮 1 Jogador</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.botao}
          onPress={() => setTela('doisJogadores')}>
          <Text style={styles.textoBotao}>👥 2 Jogadores</Text>
        </TouchableOpacity>

        <Text style={styles.creditos}>
          desenvolvido por @isadorapedon, @helenadalponso e @isabellimartielo
        </Text>
      </SafeAreaView>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  titulo: {
    fontSize: 38,
    fontWeight: 'bold',
    color: '#6B3A4C',
    marginBottom: 10,
    fontFamily: 'century gothic',
  },
  subtitulo: {
    fontSize: 18,
    color: '#8A5265',
    marginBottom: 25,
    fontFamily: 'century gothic',
  },
  botao: {
    width: '80%',
    backgroundColor: '#8A3B58',
    paddingVertical: 18,
    borderRadius: 15,
    alignItems: 'center',
    marginBottom: 20,
    elevation: 5,
  },
  textoBotao: {
    color: '#fff',
    fontSize: 20,
    fontWeight: 'bold',
    fontFamily: 'century gothic',
  },
  textoBotao1: {
    color: '#fff',
    fontSize: 9,
    fontWeight: 'bold',
    fontFamily: 'century gothic',
  },
  creditos: {
    position: 'absolute',
    bottom: 20,
    textAlign: 'center',
    fontSize: 9,
    color: '#000',
    fontFamily: 'century gothic',
  },
  botaoVoltar: {
    position: 'absolute',
    top: 100,
    left: 15,
    backgroundColor: '#8A3B58',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 8,
    elevation: 5,
  },
});
